#!/bin/bash  
#SBATCH --job-name="mnabia2Job1"  
#SBATCH --output="ANN_Part1.%j.%N.out"
#SBATCH --partition=compute  
#SBATCH --nodes=1  
#SBATCH --ntasks-per-node=24 
#SBATCH --export=ALL  
#SBATCH -t 03:30:00

python ANN_Surrogate_Part1.py
